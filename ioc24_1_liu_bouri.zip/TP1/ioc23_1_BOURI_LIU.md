# TP1 Hello World!
> - Remarques : ceci est un modèle proposé pour vos comptes-rendus. 
> - Changer les titres pour qu'ils correspondent au sujet du compte-rendu. Par exemple : `TPx titre du TP` devient `TP1 Driver LED et BP`
> - Remettez les questions, et pas seulement les réponses, pour que vous puissiez facilement relire votre CR.
> - Vous pouvez mettre des liens externe par ex. [syntaxe markdown](https://www.markdownguide.org/cheat-sheet)
> - Utiliser l'éditeur VScode : `code` pour l'édition, vous aurez un prévisualisation.
> - Faites simple mais lisible et compréhensible 
> - Vous pouvez mettre des liens externes

## Auteurs

- BOURI Raïssa 28602820
- LIU   Owen   28

## Réponses aux questions du TME

-`Ecrire un résumé de la question 1 (en moins d'une phrase)
  - réponse 1...

- résumé de la question2
  - réponse 2
  - peut-être sur plusieurs lignes

## Expériences réalisées

### Titre de l'expérience

- Décrire sous forme d'une liste les étapes
  - éventuellement les sous-étapes 1
  - une sous étape 2
  - etc

- Une nouvelle étape de l'expériences

- etc.

##
